# MHP3 DATABASE — Proyecto Android offline (v0.4)

## Cambios de esta entrega
- La app sigue siendo offline, en español y mantiene las 9 secciones aprobadas.
- Se agregan catálogos locales transcritos desde los índices públicos consultados: 48 armas (rareza/ataque), 48 piezas de armadura (rareza/defensa), 48 misiones (rango/objetivo/zona/recompensa), 48 combinaciones (ingredientes/tasa/cantidad), 48 objetos (rareza/precio/límite) y 48 habilidades (descripción traducida).
- Los registros se muestran en sus secciones y en sus fichas sin necesitar conexión.
- Se conserva la ficha detallada verificada de Zinogre y los 260 recursos gráficos locales extraídos del APK que aportaste.

## Cobertura: no confundir índice con base completa
Las fuentes consultadas publican estos totales para MHP3rd: 64 entradas de monstruos (40 grandes y 24 pequeños), 987 armas, 1.131 piezas de armadura, 331 misiones, 978 objetos, 117 combinaciones y 209 habilidades. Esta versión importa primeras páginas de los índices para armas, armaduras, misiones, objetos, combinaciones y habilidades. Por tanto, NO contiene todavía todos esos registros ni todos sus campos.

- Monstruos: 60 registros visuales procedentes de los recursos de la APK; solo Zinogre tiene en esta entrega hitzones, partes rompibles y tabla de materiales individual verificada. No se inventan datos para el resto.
- Armas: 48 registros de catálogo con rareza y ataque; los árboles completos, filo, elemento, munición y materiales de las 987 armas siguen pendientes.
- Armaduras: 48 piezas con rareza y defensa base; resistencias, ranuras, habilidades y materiales por pieza siguen pendientes.
- Misiones: 48 misiones con rango, objetivo, zona y recompensa; faltan las páginas restantes hasta 331 y su etiquetado exhaustivo por categoría.
- Imágenes: 260 recursos locales; varias criaturas comparten iconos o ilustraciones de variante.

## Fuentes y atribución
- Monster Hunter Wiki / Fandom: https://monsterhunter.fandom.com/wiki/Category:MHP3_Database
- Hunterpedia MHP3rd: https://thehunterpedia.com/monster-hunter-portable-3rd
- Hunterpedia armas: https://thehunterpedia.com/monster-hunter-portable-3rd/weapons
- Hunterpedia armaduras: https://thehunterpedia.com/monster-hunter-portable-3rd/armor
- Hunterpedia misiones: https://thehunterpedia.com/monster-hunter-portable-3rd/quests
- Hunterpedia objetos: https://thehunterpedia.com/monster-hunter-portable-3rd/items
- Hunterpedia combinaciones: https://thehunterpedia.com/monster-hunter-portable-3rd/combos
- Hunterpedia habilidades: https://thehunterpedia.com/monster-hunter-portable-3rd/skills
- Monster Hunter Portable 3rd Wiki, monstruos: https://mh.mtwildwood.net/mhp3/monsters/
- Monster Hunter Portable 3rd Wiki, Zinogre: https://mh.mtwildwood.net/mhp3/monsters/zinogre/

Hunterpedia declara que es una base de fans y no está afiliada, respaldada ni aprobada por Capcom. Monster Hunter, nombres, arte y contenido son propiedad de sus titulares. Los datos se traducen y resumen; conserva estas atribuciones y verifica permisos antes de distribuir públicamente.

## Compilar
Abrir en Android Studio con JDK 17 y Android SDK 35 y ejecutar Build > Build APK(s). El APK debug aparecerá en `app/build/outputs/apk/debug/app-debug.apk`. Este entorno no tiene Android SDK/Gradle instalados; por tanto esta entrega es código fuente, no APK compilada ni probada en dispositivo.

## Compilar usando solo un teléfono Android (GitHub Actions)
1. En el navegador del teléfono, inicia sesión o crea una cuenta en GitHub.
2. Crea un repositorio nuevo, por ejemplo `MHP3-DATABASE`.
3. Sube el contenido de esta carpeta al repositorio (no subas la carpeta contenedora duplicada).
4. Abre la pestaña **Actions**, selecciona **Construir APK MHP3 DATABASE** y pulsa **Run workflow**. También se ejecuta al subir cambios a `main` o `master`.
5. Cuando termine correctamente, abre la ejecución y descarga el artefacto **MHP3-DATABASE-APK**.
6. Descomprime el ZIP del artefacto y abre `app-debug.apk` en Android. Si Android lo solicita, permite instalar aplicaciones desde el navegador/gestor de archivos.

La compilación en la nube necesita internet; la app instalada no necesita internet para consultar los recursos y datos empaquetados. La APK debug no está firmada para publicación en Play Store.
